package com.example.cooperation_project.repository;

import com.example.cooperation_project.entity.LoveComment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoveCommentRepository extends JpaRepository<LoveComment, Long> {

}